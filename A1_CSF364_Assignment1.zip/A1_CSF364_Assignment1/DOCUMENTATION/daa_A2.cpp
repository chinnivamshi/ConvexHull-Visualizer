#include <bits/stdc++.h>
using namespace std;

int dp[100][100];
int l = 0;
struct pairArray
{
    char first;
    char second;
    int num1;
    int num2;
};

pairArray pairingArray[100];

int check_exists(int check)
{
    for (int k = 0; k < l; k++)
    {
        if (check == pairingArray[k].num1 || check == pairingArray[k].num2)
            return 1;
    }
    return 0;
}

void pairs(int i, int j, string s)
{
    if (j <= i)
        return;

    if (dp[i][j] == dp[i][j - 1])
        pairs(i, j - 1, s);

    for (int k = i; k < j - 4; k++)
    {
        if (k - 1 < 0)
        {
            if (dp[i][j] == dp[k + 1][j - 1] + 1)
            {
                int checkK = check_exists(k);
                int checkJ = check_exists(j);
                if (checkK == 0 && checkJ == 0)
                {
                    pairingArray[l].num1 = k;
                    pairingArray[l].num2 = j;
                    pairingArray[l].first = s[k - 1];
                    pairingArray[l].second = s[j - 1];
                    l++;
                }
                pairs(k + 1, j - 1, s);
            }
        }
        else if (dp[i][j] == dp[i][k - 1] + dp[k + 1][j - 1] + 1)
        {
            int checkK = check_exists(k);
            int checkJ = check_exists(j);
            if (checkK == 0 && checkJ == 0)
            {
                pairingArray[l].num1 = k;
                pairingArray[l].num2 = j;
                pairingArray[l].first = s[k - 1];
                pairingArray[l].second = s[j - 1];
                l++;
            }
            pairs(i, k - 1, s);
            pairs(k + 1, j - 1, s);
        }
    }
}

int OPT(int i, int j, int n, string str)
{
    if (i >= j - 4)
        return 0;
    if (dp[i][j] != -1)
        return dp[i][j];

    int notTake = 0;
    if (dp[i][j - 1] == -1)
    {
        dp[i][j - 1] = OPT(i, j - 1, n, str);
        notTake = dp[i][j - 1];
    }

    int take = 0;

    for (int t = i; t <= j - 5; t++)
    {
        if ((str[t - 1] == 'A' && str[j - 1] == 'U') || (str[t - 1] == 'U' && str[j - 1] == 'A') || (str[t - 1] == 'C' && str[j - 1] == 'G') || (str[t - 1] == 'G' && str[j - 1] == 'C'))
        {
            if (dp[t + 1][j - 1] == -1)
                dp[t + 1][j - 1] = OPT(t + 1, j - 1, n, str);
            if (dp[i][t - 1] == -1)
                dp[i][t - 1] = OPT(i, t - 1, n, str);
            take = max(take, 1 + dp[i][t - 1] + dp[t + 1][j - 1]);
        }
    }

    return dp[i][j] = max(take, notTake);
}

int main()
{
    string rna;
    cin >> rna;
    int n = rna.length();

    memset(dp, -1, sizeof(dp));

    // Initialize the matrix with 0 for all pairs with i >= j-4
    for (int i = 0; i <= n; i++)
    {
        for (int j = 0; j <= n; j++)
        {
            if (i >= j - 4)
                dp[i][j] = 0;
        }
    }

    for (int k = 5; k < n; k++)
    {
        for (int i = 1; i <= n - k; i++)
        {
            int j = k + i;
            dp[i][j] = OPT(i, j, n, rna);
        }
    }

    pairs(1, n, rna);
    cout << "The number of pairs are " << dp[1][n] << endl;

    cout << "The pairs are " << endl;

    for (int i = 0; i < l; i++)
    {
        cout << pairingArray[i].first << pairingArray[i].second << " " << pairingArray[i].num1 << " " << pairingArray[i].num2 << endl;
    }

    return 0;
}